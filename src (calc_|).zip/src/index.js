import React from 'react';
import ReactDOM from 'react-dom';
import CalculatorApp from './CalculatorApp'
import CalculatorAppTwo from './CalculatorApp2'

ReactDOM.render(
  <React.StrictMode>
    
    <CalculatorAppTwo />

  </React.StrictMode>,
  document.getElementById('root')
);

