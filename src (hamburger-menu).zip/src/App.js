import React, { useState } from 'react';

import Toolbar from './components/Toolbar/Toolbar'
import SideDrawer from './components/SideDrawer/SideDrawer'
import BackDrop from './components/BackDrop/BackDrop'

function App() {
  const [isOpen, setOpen] = useState (false)

  function handleOpen () {
    setOpen (currentOpen => !currentOpen);
  }

  function handleClose () {
    setOpen (false);
  }

  //let sideDrawer = null;
  //let backDrop = null
  //if (isOpen) {
    //sideDrawer =  <SideDrawer/> 
    //backDrop = <BackDrop click = {handleClose} isOpen = {isOpen}/>
  //}

  return (
    <div style = {{height: '100vh'}}>
      <Toolbar  click = {handleOpen} isOpen = {isOpen}/>
      <SideDrawer isOpen = {isOpen}/>
      <BackDrop click = {handleClose} isOpen = {isOpen}/>
      <main style = {{marginTop: 80}}>
        <p>The content itself</p>
      </main>
      
    </div>

  )
}

export default App;
