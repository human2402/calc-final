import React from 'react';

import './DrawerToggleButton.css'

function DrawerToggleButton (props) {
    const isOpen = props.isOpen;

    let firstLine = 'first-line';
    if (isOpen) {firstLine = 'first-line is-open'};
    let secondLine = 'second-line';
    if (isOpen) {secondLine = 'second-line  is-open'};
    let crossLine = 'cross-line';
    if (isOpen) {crossLine = 'cross-line  is-open'};


    return (
        <button className = 'button'>
        
            <div className = {firstLine}></div>
            <div className = {secondLine}>
                <div className = {crossLine}></div>
            </div>
            <div className = 'third-line'></div>
        
        </button>
    )
}

export default DrawerToggleButton;