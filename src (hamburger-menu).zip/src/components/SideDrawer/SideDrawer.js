import React from 'react';

import './SideDrawer.css'

function SideDrawer (props) {

    let open = 'side-drawer'
    if (props.isOpen) {
        open = 'side-drawer open'
    }

    return (
        <nav className = {open}>
            <ul>
                <li><a>Products</a></li>
                <li><a>Users</a></li>
            </ul>
        </nav>
    )
}

export default SideDrawer;