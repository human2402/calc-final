import React from 'react';

import './Toolbar.css'

import DrawerToggleButton from '../SideDrawer/DrawerToggleButton'

function Toolbar (props) {
    return (
        <header className = 'toolbar'>
            <nav className = 'toolbar-navigation'>
                <div 
                    className = 'super-button'
                    onClick = {props.click}
                >
                    <DrawerToggleButton isOpen = {props.isOpen}/>
                </div>
                <div className = 'toolbar-logo'><a>The Logo</a></div>
                <div className = 'space'></div>
                <div className = 'toolbar-items'>
                    <ul>
                        <li><a>Products</a></li>
                        <li><a>Users</a></li>
                    </ul>
                </div>
            </nav>
        </header>
    )
}

export default Toolbar;