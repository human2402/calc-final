import React from 'react';

import './BackDrop.css'

function BackDrop (props) {

            let open = 'back-drop'
            if (props.isOpen) {
                open = 'back-drop open'
            }

    return (
        <div 
            onClick = {props.click}
            className = {open}
        />
    )
}

export default BackDrop;